﻿using EmployeeSalaryApi.DTOs;

namespace EmployeeSalaryApi.Repositories
{
    public interface IEmployeeRepository
    {
        Task<IEnumerable<EmployeeDto>> GetEmployeesWithSalariesAsync();
    }
}
