﻿using EmployeeSalaryApi.Data;
using EmployeeSalaryApi.DTOs;
using EmployeeSalaryApi.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeSalaryApi.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly ApplicationDbContext _context;

        public EmployeeRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<EmployeeDto>> GetEmployeesWithSalariesAsync()
        {
            return await _context.Employees
                .Include(e => e.SalaryDetails)
                .Select(e => new EmployeeDto
                {
                    Id = e.Id,
                    Name = e.Name,
                    Department = e.Department,
                    SalaryDetails = e.SalaryDetails
                        .OrderBy(s => s.MonthYear)
                        .Select(s => new SalaryDetailDto
                        {
                            MonthYear = s.MonthYear,
                            SalaryAmount = s.SalaryAmount
                        }).ToList()
                })
                .ToListAsync();
        }
    }
}
