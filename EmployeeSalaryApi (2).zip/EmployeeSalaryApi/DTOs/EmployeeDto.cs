﻿namespace EmployeeSalaryApi.DTOs
{
    public class EmployeeDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public List<SalaryDetailDto> SalaryDetails { get; set; } = new();
    }
}
