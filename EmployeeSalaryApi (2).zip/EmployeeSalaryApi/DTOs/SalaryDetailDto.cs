﻿namespace EmployeeSalaryApi.DTOs
{
    public class SalaryDetailDto
    {
        public DateTime MonthYear { get; set; }
        public decimal SalaryAmount { get; set; }
    }
}
