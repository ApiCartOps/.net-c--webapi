﻿namespace EmployeeSalaryApi.Models
{
    public class SalaryDetail
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public DateTime MonthYear { get; set; }
        public decimal SalaryAmount { get; set; }
        public Employee Employee { get; set; } = null!;
    }
}
