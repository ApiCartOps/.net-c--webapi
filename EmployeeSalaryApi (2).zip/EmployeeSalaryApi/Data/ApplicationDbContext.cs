﻿using EmployeeSalaryApi.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeSalaryApi.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<SalaryDetail> SalaryDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<SalaryDetail>()
                .HasOne(s => s.Employee)
                .WithMany(e => e.SalaryDetails)
                .HasForeignKey(s => s.EmployeeId);
        }
    }
}
