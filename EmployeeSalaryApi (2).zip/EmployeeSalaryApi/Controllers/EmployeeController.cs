﻿using EmployeeSalaryApi.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeSalaryApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        [HttpGet("employees-with-salaries")]
        public async Task<IActionResult> GetEmployeesWithSalaries()
        {
            var employees = await _employeeRepository.GetEmployeesWithSalariesAsync();
            return Ok(employees);
        }
    }
}
